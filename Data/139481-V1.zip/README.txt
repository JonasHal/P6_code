Required data and file structure
Due to a non-disclosure agreement between UC Berkeley and Pacific Gas and Electric (PG&E), we are unable to release the electricity data for this project publicly. 
Academic researchers wishing to replicate our results can submit a request through the Energy Data Request Program: https://pge-energydatarequest.com
We are also unable to release the DMV data for this project publicly. This data can be obtained from the DMV directly. The data are also housed with Experian and RL Polk. 


MAIN PROJECT FOLDER
|-- Code
|   |-- Analyze
|   |-- Build
|   |-- Produce_output
|-- Data
|   |-- Raw
|       |-- Interval
|       |-- Customer
|       |-- Cbg
|       |-- DMV
|   |-- Generated
|       |-- Intermediate
|                    |-- PGE
|                    |-- DMV
|       |-- Temp
|                    |-- PGE
|-- Result
|   |-- PGE

All other folders are empty, per our data agreement. In order to run the code described below, 
researchers will need to acquire the following datasets, and place them according to the below filepaths:

Customer information data: [MASTER PROJECT FOLDER]/Data/Raw/Customer/
Fifteen-minute-interval AMI data :[MASTER PROJECT FOLDER]/Data/Raw/Interval/
California DMV EV registration records data :[MASTER PROJECT FOLDER]/Data/Raw/DMV/

Census Block Group data:[MASTER PROJECT FOLDER]/Data/Raw/Cbg/ is downloaded from US Census through
https://www.census.gov/geographies/mapping-files/time-series/geo/tiger-line-file.2010.html
This census block group file is placed under Reliability/Data/Raw/Cbg

All final .dta files that are needed to generate tables and figures are placed under Reliability/Result/PGE


Code
Upon obtaining data from PG&E and DMV, and populating as per the above file structure, researchers can replicate our results by running the code in the following order:

Reliability/Code/00_MASTER_set_paths.do sets all paths for use in subsequent Stata .do files. 
Before using this, you will need to change the master paths to match your directory structure.

Reliability/Code/Build/B00_MASTER_build_all.do runs all code to build datasets in Stata. 
Note that some portions of this build are run in R. 
Researchers will have to run the R00_MASTER_build.R files in the Reliability/Code/Build folder at the appropriate time partway through the BOO_MASTER_build_all.do file.


Reliability/Code/Analyze/A00_MASTER_analyze_all.do runs all analysis code in Stata.
Note that some portions of this analyze are run in R. 
Researchers will have to run the R03_MASTER_appendix_composition.R files in the Reliability/Code/Analyze folder at the appropriate time partway through the A00_MASTER_analyze_all.do file.


Reliability/Code/Produce_output/PO00_MASTER_produce_output_all.do generates all tables (in tex format) and figures (in PDF format) in Stata for the main text and appendix.

The Reliability/Code/Build, Reliability/Code/Analyze, and Reliability/Code/Produce_output folders contain all required sub-programs.