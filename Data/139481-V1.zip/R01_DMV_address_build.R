
## ----------------------------------------------------------------
## Below is the file that summarizes the DMV address-level data
## Created by Benjamin M. Dawson
##    November 6th, 2019
## Version 1.0
## ----------------------------------------------------------------

##############################
# Load data
##############################
# Load DMV data
dmv <- list.files(paste0(file_paths$data_raw)) %>%
  enframe(value = "files", name = NULL) %>% 
  filter(str_detect(files, "\\.csv")) %>% 
  # slice(1) %>%
  pull() %>% 
  purrr::map(function(i) read_csv(paste0(file_paths$data_raw, "/", i)) %>% 
               mutate(file = i))

# Clean up the DMV data
# Open up the relevant data variables
dmv_samp_full <- 1:21 %>% 
  map_df(function(i) dmv[[i]] %>% 
           filter(STATUS_CODE == "C") %>% 
           # filter(vin_anon_ID %in% dmv_sample$vin_anon_ID) %>% 
           mutate_at(vars(vin_anon_ID, LAST_REG_DATE, LAST_OWNERSHIP_DATE, LAST_XFER_DATE, RO_ZIP), as.character) %>% 
           mutate(dmv_vint = i) %>% 
           mutate(YEAR_SOLD = as.integer(YEAR_SOLD)) %>% 
           select(vin_anon_ID, vin_8_10, 
                  LAST_REG_DATE, LAST_OWNERSHIP_DATE, LAST_XFER_DATE, YEAR_SOLD, dmv_vint, 
                  RO_ADDR1, RO_ADDR2, RO_CITY, RO_ZIP,
                  MAKE_NAME, SERIES_NAME, YEAR_MODEL, FUEL_TYPE, MOTIVE_POWER, file)) %>% 
  mutate(LAST_XFER_DATE = str_sub(LAST_XFER_DATE, -4, -1),
         LAST_XFER_DATE = str_c(LAST_XFER_DATE, "01")) %>% 
  mutate_at(vars(LAST_REG_DATE, LAST_OWNERSHIP_DATE, LAST_XFER_DATE), ymd) %>%
  mutate(file = str_remove(file, "\\.csv"),
         file = str_remove(file, "dmv"))

# Load CBG data
cbg <- get_acs(geography = "block group", state = "CA",
               variables = c(households = "B00002_001"),
               output = "wide", geometry = T)
# Load ZIP data
zip <- get_acs(geography = "zcta",
               variables = c(households = "B00002_001"),
               output = "wide", geometry = T)
zip <- zip %>%
  st_transform(st_crs(state_laea)) %>% 
  st_intersection((state_laea %>% filter(GEOID == "06"))) %>% 
  pull(GEOID) %>% 
  enframe(name = NULL, value = "ZIP")

# Add in lat-long data
addresses_lat_long <- read_csv(paste0(file_paths$data_raw, "[ADDRESS TO LAT-LONG]")) %>% 
  distinct()

# VIN Deocoders
vin_decoder <- readxl::read_excel(paste0(file_paths$data_raw, 
                                         "[VIN DECODER HERE]")) %>% 
  # Clean the VIN decoder to merge with DMV data
  mutate(vin_8_10 = str_c(VIN, `MYEAR VIN CODE`),
         Model = case_when(
           str_detect(Model, "Model S") ~ "Model S",
           str_detect(Model, "ForTwo EV") ~ "ForTwo",
           TRUE ~ Model
         )) %>% 
  mutate(Tech = if_else(Tech == "BEVx", "PHEV", Tech))

##############################
# Fix Addresses
##############################
dmv_samp_full_hold <- dmv_samp_full
# Flip if there is the appartment (or the like) in the first column (RO_ADDR1)
dmv_samp_full <- dmv_samp_full %>%
  mutate(first_letter = str_sub(RO_ADDR1, 1, 1),
         first_word = str_extract(RO_ADDR1, "\\w*"),
         addr_hold = RO_ADDR1,
         # Flip if APT (etc.) comes in RO_ADD1 and address is in RO_ADDR2
         RO_ADDR1_a = if_else(
           str_detect(RO_ADDR1, "\\bAPT\\b|\\bUNIT\\b|\\bSTE\\b") &
             str_detect(first_letter, "\\d", negate = T) &
             str_detect(first_word, "\\bAPT\\b|\\bUNIT\\b|\\bSTE\\b"),
           RO_ADDR2,
           RO_ADDR1
         ),
         # Fix the switch
         RO_ADDR2_a = if_else(
           str_detect(RO_ADDR2, "\\bAPT\\b|\\bUNIT\\b|\\bSTE\\b") &
             str_detect(first_letter, "\\d", negate = T) &
             str_detect(first_word, "\\bAPT\\b|\\bUNIT\\b|\\bSTE\\b"),
           addr_hold,
           RO_ADDR2
         ),
         # Re-do this to make sure it's correct for the new arrangement
         first_letter = str_sub(RO_ADDR1, 1, 1),
         # Add APT (etc.) if these are separate
         RO_ADDR1_b = if_else(
           str_detect(RO_ADDR2_a, "\\bAPT\\b|\\bUNIT\\b|\\bSTE\\b") & 
             # str_detect(first_word, "\\bAPT\\b|\\bUNIT\\b|\\bSTE\\b") &
             !is.na(RO_ADDR2_a) &
             str_detect(RO_ADDR1_a, RO_ADDR2_a, negate = T),
           str_c(RO_ADDR1_a, RO_ADDR2_a, sep = " "),
           RO_ADDR1_a
         )) %>% 
  mutate(RO_ADDR1 = RO_ADDR1_b) %>% 
  # Switching for the PO Box
  mutate(RO_ADDR1 = if_else(str_detect(RO_ADDR1, "PO B") &
                              !is.na(RO_ADDR2_a) &
                              str_detect(str_sub(RO_ADDR2_a, 1, 1), "\\d"),
                            RO_ADDR2_a,
                            RO_ADDR1))

##############################
# Addresses to CBG
##############################
# Generate address data from DMV data
address_all <- dmv_samp_full %>%
  mutate(address = str_c(RO_ADDR1, " ", RO_CITY, ", CA " ,RO_ZIP, " USA")) %>%
  distinct(RO_ADDR1, RO_CITY, RO_ZIP, address) %>%
  # anti_join(addresses_lat_long) %>%
  drop_na()

# Addresses to a spatial object
addresses_sf <- addresses_lat_long %>% 
  drop_na() %>% 
  st_as_sf(coords = c("lon", "lat"), remove = FALSE, crs = 4326) %>% 
  st_transform(st_crs(cbg))

# Place addresses in CBGs
addresses_cbg <- addresses_sf %>% 
  st_join(cbg, join = st_intersects) %>% 
  as_tibble() %>% 
  select(address, lon, lat, GEOID) %>% 
  rename(cbg = GEOID)

# Merge addresses to DMV data
dmv_samp_full <- dmv_samp_full %>%
  mutate(address = str_c(RO_ADDR1, " ", RO_CITY, ", CA " ,RO_ZIP, " USA")) %>%
  left_join(addresses_cbg)

##############################
# Clean DMV data to transactions
##############################
dmv_dated <- dmv_samp_full %>% 
  arrange(vin_anon_ID, file) %>% 
  mutate(PurchaseDate = if_else(!is.na(LAST_OWNERSHIP_DATE), 
                                LAST_OWNERSHIP_DATE, 
                                if_else(!is.na(LAST_REG_DATE), 
                                        LAST_REG_DATE, LAST_XFER_DATE))) %>% 
  select(vin_anon_ID:LAST_XFER_DATE, PurchaseDate, cbg, address, everything()) %>% 
  filter(!is.na(SERIES_NAME), !is.na(PurchaseDate)) %>% 
  distinct(vin_anon_ID, 
           LAST_REG_DATE, LAST_XFER_DATE, LAST_OWNERSHIP_DATE, PurchaseDate, 
           cbg, address, lat, lon,
           vin_8_10, SERIES_NAME, YEAR_MODEL, FUEL_TYPE, MOTIVE_POWER) %>% 
  arrange(LAST_REG_DATE) %>% 
  group_by(vin_anon_ID) %>% 
  mutate(mover = if_else(address != lag(address) & 
                           PurchaseDate == lag(PurchaseDate), 
                         TRUE, FALSE),
         MoverDate = if_else(address != lag(address) & 
                               PurchaseDate == lag(PurchaseDate), 
                             LAST_REG_DATE, as.Date(NA))) %>% 
  replace_na(list(mover = FALSE)) %>% 
  group_by(vin_anon_ID, address, PurchaseDate) %>%
  mutate(mover = if_else(any(mover), TRUE, FALSE)) %>%
  ungroup() %>% 
  distinct(vin_anon_ID, PurchaseDate, MoverDate, mover, vin_8_10, 
           cbg, address, lat, lon) %>%
  mutate(FullDate = if_else(mover, MoverDate, PurchaseDate)) %>% 
  select(vin_anon_ID, FullDate, everything()) %>% 
  filter(!is.na(FullDate)) %>% 
  arrange(vin_anon_ID, FullDate)

# Add the non-re-registered automobiles
## Get the non-re-registered vehicles
dmv_losses_no_reg <- dmv_samp_full %>% 
  group_by(vin_anon_ID) %>% 
  filter(LAST_REG_DATE == max(LAST_REG_DATE)) %>% 
  ungroup() %>% 
  filter(LAST_REG_DATE < ymd(20161010))
# Create a data set to join to the dmv_dated data set
dmv_losses_no_reg <- dmv_losses_no_reg %>% 
  arrange(vin_anon_ID, file) %>% 
  mutate(PurchaseDate = if_else(!is.na(LAST_OWNERSHIP_DATE), 
                                LAST_OWNERSHIP_DATE, 
                                if_else(!is.na(LAST_REG_DATE), 
                                        LAST_REG_DATE, LAST_XFER_DATE))) %>% 
  mutate(FullDate = LAST_REG_DATE) %>% 
  distinct(vin_anon_ID, FullDate, vin_8_10, PurchaseDate, cbg, address, lon, lat) %>% 
  mutate(mover = FALSE,
         no_re_reg = TRUE)

# Join to dated data
dmv_dated <- dmv_dated %>% 
  bind_rows(dmv_losses_no_reg)

dmv_dated <- dmv_dated %>% 
  distinct() %>% 
  left_join(
    vin_decoder %>% 
      distinct(vin_8_10, Manufacturer, Make, Model, Tech, ModelYear...5) %>% 
      rename(ModelYear = ModelYear...5)
  )

# Capture just the addresses and dates
dmv_addr_test <- dmv_dated %>% 
  group_by(vin_anon_ID, address) %>% 
  mutate(after_2017 = year(FullDate) > 2017) %>% 
  ungroup()
dmv_addr_test <- dmv_addr_test %>% 
  group_by(address) %>% 
  mutate(after_2017 = !any(!after_2017)) %>% 
  ungroup() %>% 
  distinct(address, after_2017)
dmv_addr_test %>% 
  distinct(address, after_2017) %>%
  inner_join(address_all) %>% 
  filter(!is.na(address)) %>% 
  write_rds(paste0(file_paths$data_intermediate, "addresses_all.rds"))

# Save the data for the address level analysis
dmv_dated %>% 
  rename(address_dmv = address) %>% 
  write_dta(paste0(file_paths$data_intermediate, "address_DMV.dta"))
