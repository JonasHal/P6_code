
## ----------------------------------------------------------------
## Create PGE market share data
## Written by: Ben Dawson
## Contact: bdawson@ucdavis.edu
## Updated: February 25th, 2020
## ----------------------------------------------------------------

# Top ten EVs sold in CA and PGE comparison
dmv_dated %>% 
  rename(address_dmv = address) %>% 
  mutate(zip_code = str_extract(address_dmv, "CA \\d{5}"),
         zip_code = str_remove(zip_code, "CA "),
         zip_code = as.double(zip_code)) %>% 
  filter(zip_code %in% pge_zips) %>% 
  # End comment need
  filter(year(FullDate) <= 2017) %>% 
  left_join(addresses_pge_evs %>% 
              distinct(address_dmv) %>% 
              mutate(PGE = TRUE)) %>% 
  replace_na(list(PGE = FALSE)) %>% 
  distinct(vin_anon_ID, vin_8_10, Make, Model, PGE) %>% 
  mutate(Model = str_remove(Model, " \\(xDrive\\)")) %>% 
  left_join(
    vin_decoder %>% select(vin_8_10, capacity) %>% distinct() %>% group_by(vin_8_10) %>% summarise(capacity = mean(capacity))
  ) %>%
  mutate(Model = case_when(
    Make == "BMW" & str_detect(Model, "i3") ~ "i3",
    # Adding the differentiation of Leafs
    Make == "Nissan" & Model == "Leaf" & (capacity == 24 | is.na(capacity)) ~ "Leaf-24",
    Make == "Nissan" & Model == "Leaf" & capacity != 24 ~ "Leaf-30+",
    TRUE ~ Model
  )) %>% 
  count(Make, Model, PGE) %>% 
  pivot_wider(names_from = PGE, values_from = n) %>% 
  replace_na(list(`FALSE` = 0, `TRUE` = 0)) %>% 
  rename(PGE = `TRUE`,
         Total = `FALSE`) %>% 
  mutate(Total = Total + PGE) %>% 
  filter(Make != "") %>% 
  arrange(Make, Model) %>% 
  arrange(desc(Total)) %>% 
  mutate(Total_total = sum(Total),
         PGE_total = sum(PGE),
         Total = Total / Total_total * 100,
         PGE = PGE / PGE_total * 100,
         MM = str_c(Make, Model, sep = " ")) %>% 
  slice(1:12) %>% 
  write_dta(paste0(file_paths$data_intermediate, "EV_marketshare_PGE.dta"))

