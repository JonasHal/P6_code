
## ----------------------------------------------------------------
## Below is the file that summarizes the DMV address-level data
## Created by Benjamin M. Dawson
##    November 6th, 2019
## Version 1.0
## ----------------------------------------------------------------

###############
# Globals
###############
# File paths
parent_path <- "[PARENT PATH HERE]"
file_paths <- list(
  code_global = paste0(parent_path, "[CODE PATH HERE]"),
  data_raw = paste0(parent_path, "[RAW DATA PATH HERE]"),
  data_intermediate = paste0(parent_path, "[INTERMEDIATE DATA PATH HERE")
); rm(parent_path)

###############
# Load Packages
###############
# General packages needed
library(stringr)
library(lubridate)
library(viridis)
library(readxl)
# US Census Data
library(tidycensus)
census_api_key("[ENTER KEY HERE]")
library(maps)
# Utilities
library(ggfortify)
library(haven)
# Aesthetics
library(hrbrthemes)
library(gcookbook)
# Geocode
library(ggmap)
library(sf)
# Laod last to avoid masking functionality
library(tidyverse)

##############################
# Load data
##############################
# Load and clean DMV data
source(paste0(file_paths$code_global, "B01_R_DMV_address.R"))

# Load PGE data and match to DMV data
source(paste0(file_paths$code_global, "B02_R_merge_addresses_PGE.R"))