
## ----------------------------------------------------------------
## Merge the DMV addresses with PGE data
## Written by: Ben Dawson
## Contact: bdawson@ucdavis.edu
## Updated: February 25th, 2020
## ----------------------------------------------------------------

# Open Data
## Addresses
addresses_evs <- read_rds(paste0(file_paths$data_intermediate, "addresses_all.rds"))

## PGE
addresses_pge <- read_dta(paste0(file_paths$data_raw, "[PGE ADDRESS DATA]"))

#########################################################
# Cleaning Addresses of DMV and IOU Data 
#########################################################
# Function to standardize and clean addresses
clean_address <- function(addr, full = TRUE){
  addr <- tolower(addr)
  addr <- gsub("[^[:alnum:] ]", "", addr)
  if (full) {
    addr <- mgsub::mgsub(addr, c("street", "drive","road","avenue",
                                 "circle","lane"," trail","grove",
                                 " bend", "boulevard", "vly", "\\bplace\\b",
                                 "\\bwest\\b", "\\beast\\b", "\\bnorth\\b", "\\bsouth\\b",
                                 "\\bso\\b", "\\bterr\\b", "\\bway\\b"), 
                         c("st", "dr","rd","ave",
                           "cir","ln"," trl","grv",
                           " bnd", "blvd", "valley", "pl",
                           "w", "e", "n", "s",
                           "s", "ter", "wy"))
  }
  addr <- gsub("\\s+", " ", str_trim(addr))
  return(addr)
}

# Cleaning DMV addresses
addresses_evs <- addresses_evs %>% 
  mutate(RO_ADDR1 = clean_address(RO_ADDR1),
         RO_CITY = clean_address(RO_CITY, full = FALSE))
addresses_pge <- addresses_pge %>% 
  mutate(prem_address = clean_address(prem_address),
         prem_city = clean_address(prem_city, full = FALSE))

# Rename the variables to match on them
addresses_evs <- addresses_evs %>%
  rename(addr = RO_ADDR1,
         city = RO_CITY,
         zip = RO_ZIP) %>%
  mutate(zip = as.numeric(zip))
addresses_pge <- addresses_pge %>% 
  rename(addr = prem_address,
         city = prem_city,
         zip = prem_zip,
         cbg = sp_geocode) %>% 
  mutate(addr_pge = addr)

# Clean city names
addresses_evs <- addresses_evs %>% 
  # filter(str_detect(city, "mtn")) %>%
  mutate(city = mgsub::mgsub(
    city,
    c(
      "vly", "vl", "lk", "hls", "sn ",
      "sn ls", "obis.*", "baut", "margar",
      "hls", "hlls", "\\bhil\\b", "\\bhl\\b",
      "rough ready", "\\brllng\\b", "\\brlng\\b", "\\brling\\b",
      "rail rd", "\\bmtn\\b", "moutain", "\\bwy\\b"
    ),
    c(
      "valley", "valley", "lake", "hills", "san ",
      "san luis", "obispo", "bautista", "margarita",
      "hills ", "hills", "hill", "hill",
      "rough and ready", "rolling", "rolling", "rolling",
      "rail road", "mountain", "mountain", "way"
    )
  )) %>%
  rename(address_dmv = address) %>% 
  mutate(addr_dmv = addr)
  
#########################################################
# Joining DMv and IOU data
#########################################################
# Exact matching
addresses_pge_evs <- addresses_evs %>% 
  inner_join(addresses_pge,
             by = c("addr", "city", "zip")) %>% 
  mutate(match = "exact")
  
# Match on address and city
addresses_pge_evs <- addresses_pge %>%
  anti_join(addresses_pge_evs) %>% 
  arrange(city, addr) %>% 
  inner_join(addresses_evs,
             by = c("addr", "city")) %>% 
  rename(zip = zip.x,
         zip_dmv = zip.y) %>% 
  select(-zip_dmv) %>% 
  mutate(match = "addr_city") %>% 
  bind_rows(addresses_pge_evs, .)

# Match on address and zip
addresses_pge_evs <- addresses_pge %>%   
  anti_join(addresses_pge_evs) %>%  
  arrange(zip, addr) %>% 
  inner_join(addresses_evs,
             by = c("addr", "zip")) %>% 
  rename(city = city.x,
         city_dmv = city.y) %>% 
  select(-city_dmv) %>% 
  mutate(match = "addr_zip") %>% 
  bind_rows(addresses_pge_evs, .)

# Exact matching - remove white space
addresses_pge_evs <- addresses_pge %>%   
  anti_join(addresses_pge_evs) %>% 
  mutate(addr_match = str_remove_all(addr, " ")) %>%
  inner_join(addresses_evs %>% 
               mutate(addr_match = str_remove_all(addr, " ")),
             by = c("addr_match", "city", "zip")) %>% 
  select(-addr_match, -addr.x, -addr.y) %>% 
  mutate(match = "exact_compound") %>% 
  bind_rows(addresses_pge_evs, .)

# Exact matching - remove apartment name and white space
addresses_pge_evs <- addresses_pge %>%   
  anti_join(addresses_pge_evs) %>% 
  mutate(addr_match = str_remove(addr, "\\bapt\\b|\\bunit\\b|\\bste\\b|\\bno\\b|#"),
         addr_match = str_remove_all(addr_match, " ")) %>%
  inner_join(addresses_evs %>% 
               mutate(addr_match = str_remove(addr, "\\bapt\\b|\\bunit\\b|\\bste\\b|\\bno\\b|#"),
                      addr_match = str_remove_all(addr_match, " ")),
             by = c("addr_match", "city", "zip")) %>% 
  select(-addr_match, -addr.x, -addr.y) %>%
  mutate(match = "exact_compound_rm_apt") %>% 
  bind_rows(addresses_pge_evs, .)

# Exact matching - remove apartment name, roadtype (e.g. rd, dr, ave, etc), and white space
addresses_pge_evs <- addresses_pge %>%   
  anti_join(addresses_pge_evs) %>% 
  mutate(addr_match = str_remove(addr, "\\bapt\\b|\\bunit\\b|\\bste\\b|\\bno\\b|#"),
         addr_match = str_remove(addr_match,
                                 paste0(c("\\bst", "dr","rd","ave",
                                          "cir","ln"," trl","grv",
                                          " bnd", "blvd", "valley", "pl\\b"), collapse = "\\b|\\b")),
         addr_match = str_remove_all(addr_match, " ")) %>%
  inner_join(addresses_evs %>% 
               mutate(addr_match = str_remove(addr, "\\bapt\\b|\\bunit\\b|\\bste\\b|\\bno\\b|#"),
                      addr_match = str_remove(addr_match,
                                              paste0(c("\\bst", "dr","rd","ave",
                                                       "cir","ln"," trl","grv",
                                                       " bnd", "blvd", "valley", "pl\\b"), collapse = "\\b|\\b")),
                      addr_match = str_remove_all(addr_match, " ")),
             by = c("addr_match", "city", "zip")) %>% 
  select(-addr_match, -addr.x, -addr.y) %>%
  mutate(match = "exact_compound_rm_rd") %>% 
  bind_rows(addresses_pge_evs, .)

# Save file for analysis
addresses_pge_evs %>% 
  write_dta(paste0(file_paths$data_intermediate, "addresses_PGE.dta"))

#########################################################
# Fuzzy Match: Joining DMv and IOU data
#########################################################
# Get the zips in the EV data with the most missing EVs
missing_ev_zips <- addresses_evs %>% 
  anti_join(addresses_pge_evs,
            by = "address_dmv") %>% 
  filter(zip %in% (addresses_pge %>% 
                     filter(sample == "fs",
                            sa_status == "Active") %>% 
                     distinct(zip) %>% 
                     pull(zip))) %>% 
  count(zip) %>% 
  arrange(desc(n))

# Fuzzy matching on street address function
fuzzy_match_addr <- function(df_dmv, df_iou, zip_test){
  ## Take the top missing zip from above
  ### EVs
  test_fuzzy_string_evs <- df_dmv %>% 
    anti_join(addresses_pge_evs,
              by = "address_dmv") %>% 
    filter(zip %in% zip_test)
  ### PGE
  test_fuzzy_string_pge <- df_iou %>% 
    anti_join(addresses_pge_evs) %>% 
    filter(zip %in% zip_test)
  test_fuzzy_string_evs <- test_fuzzy_string_evs %>% 
    mutate(addr_no_number = str_remove_all(addr, "\\d"),
           addr_no_number = str_trim(addr_no_number),
           addr_number = str_extract(addr, "\\d+"))
  test_fuzzy_string_pge <- test_fuzzy_string_pge %>% 
    mutate(addr_no_number = str_remove_all(addr, "\\d"),
           addr_no_number = str_trim(addr_no_number),
           addr_number = str_extract(addr, "\\d+"))
  # Error catch
  if (nrow(test_fuzzy_string_evs) == 0 |
      nrow(test_fuzzy_string_pge) == 0) { return(tibble(match = 0, total = 0)) } 
  # Fuzzy join street names
  a <- test_fuzzy_string_evs %>% 
    inner_join(test_fuzzy_string_pge,
               by = "addr_number")
  
  if(nrow(a) > 0){
    b <- stringdist_inner_join(a %>% 
                                 select(addr_no_number.x, addr_dmv) %>% 
                                 rename(addr_no_number = addr_no_number.x),
                               a %>% 
                                 select(addr_no_number.y, addr_pge) %>% 
                                 rename(addr_no_number = addr_no_number.y),
                               distance_col = "value")
    if(nrow(b) > 0){
      b %>% 
        distinct() %>% 
        arrange(value, addr_dmv, addr_pge) %>% 
        select(value, addr_dmv, addr_pge, everything())
      
      b %>% 
        distinct(addr_no_number.x, addr_no_number.y) %>% 
        rename(addr_no_number = addr_no_number.x)
      
      df <- test_fuzzy_string_evs %>% 
        left_join(
          b %>% 
            distinct(addr_no_number.x, addr_no_number.y) %>% 
            mutate(addr_no_number = addr_no_number.x)
        ) %>% 
        mutate(addr = str_replace(addr, addr_no_number, addr_no_number.y)) %>% 
        inner_join(test_fuzzy_string_pge,
                   by = "addr")
    } else {
      df <- tibble()
    }
  } else {
    df <- tibble()
  }
    return(
      list(
        tibble(match = nrow(df), total = nrow(test_fuzzy_string_evs)),
        df
        )
      )
}
# Collect data
hold_match <- tibble()
hold_data <- tibble()
for (i in (missing_ev_zips %>% 
           arrange(zip) %>% 
           # slice(1:20) %>%
           pull(zip))){
  hold <- fuzzy_match_addr(addresses_evs, addresses_pge, i)
  hold_match <- hold_match %>% 
    bind_rows(hold[[1]] %>% mutate(zip = i))
  hold_data <- hold_data %>% 
    bind_rows(hold[[2]] %>% mutate(zip = i))
  print(i)
}

# Fuzzy match tests
hold_match %>% 
  # filter(match != 0 & total != 0) %>% 
  mutate(percent = match / total)
hold_match %>% mutate(percent = match / total) %>% 
  summarise(match = sum(match), total = sum(total)) %>% 
  mutate(percent = match / total)

# Fix data to be joined
hold_data <- hold_data %>% 
  select(zip, address_dmv, after_2017, addr, city.x, addr_dmv, sp_id:prem_uuid,
         sa_uuid:addr_pge) %>% 
  rename(city = city.x) %>% 
  mutate(match = "fuzzy")

# Join the fuzzy match data
addresses_pge_evs <- hold_data %>%
  bind_rows(addresses_pge_evs, .)

# Save file for analysis
addresses_pge_evs %>% 
  write_dta(paste0(file_paths$data_intermediate, "addresses_PGE.dta"))

